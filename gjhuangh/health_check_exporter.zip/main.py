from prometheus_client import Gauge, start_http_server
import requests
import yaml
import time

gauge = Gauge("health_check", "Health check of the target", ["name", "url"])

def getMetrics(name, url):
    resp = requests.get(url).json()

    if (resp["status"] == "UP"):
        return gauge.labels(name, url).set(1)
    elif (resp["status"] == "DOWN"):
        return gauge.labels(name, url).set(0)
    else:
        return gauge.labels(name, url).set(-1)

def getConfigs():
    with open("health_check.yaml", "r") as stream:
        data = yaml.safe_load(stream)

    print(data)
    return data

if __name__ == "__main__":
    start_http_server(5000)

    configs = getConfigs()

    while True:
        for val in configs["health_check_list"]:
            getMetrics(val["name"], val["url"])

        time.sleep(configs["intervel"])